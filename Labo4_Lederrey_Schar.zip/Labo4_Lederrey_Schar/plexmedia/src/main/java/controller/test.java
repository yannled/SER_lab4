package controller;

import javafx.fxml.FXML;

public class test {
    @FXML
    protected void initialize() {

    }
}
